package com.rockon999.android.leanbacklauncher.animation;

public interface ParticipatesInLaunchAnimation {
}
