package com.rockon999.android.leanbacklauncher;

import com.rockon999.android.leanbacklauncher.animation.ViewDimmer.DimState;

public interface DimmableItem {
    void setDimState(DimState dimState, boolean z);
}
