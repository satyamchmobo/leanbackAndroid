package com.rockon999.android.leanbacklauncher.recline.util;

public interface PostProc<T> {
    T postProcess(T t);
}
