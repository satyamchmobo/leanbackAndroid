package com.rockon999.android.leanbacklauncher;

import android.app.Application;

public class LauncherApplication extends Application {
}