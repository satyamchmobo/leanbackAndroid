package com.rockon999.android.leanbacklauncher;

import android.app.Activity;

public class DummyActivity extends Activity {
}
