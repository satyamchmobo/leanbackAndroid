package com.rockon999.android.leanbacklauncher.apps;

public interface OnEditModeChangedListener {
    void onEditModeChanged(boolean z);
}
