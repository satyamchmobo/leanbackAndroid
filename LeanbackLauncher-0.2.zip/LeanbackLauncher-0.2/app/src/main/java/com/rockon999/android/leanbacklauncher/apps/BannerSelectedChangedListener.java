package com.rockon999.android.leanbacklauncher.apps;

public interface BannerSelectedChangedListener {
    void onSelectedChanged(BannerView bannerView, boolean z);
}
