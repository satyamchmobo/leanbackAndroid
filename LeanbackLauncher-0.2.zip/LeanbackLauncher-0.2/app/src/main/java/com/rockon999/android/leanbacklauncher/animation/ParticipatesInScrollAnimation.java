package com.rockon999.android.leanbacklauncher.animation;

public interface ParticipatesInScrollAnimation {
    void setAnimationsEnabled(boolean z);
}
